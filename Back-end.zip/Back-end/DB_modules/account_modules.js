const db = require('../Database/dbConfig');

module.exports = {
    createAccount,
    loginUser,
    get
}

function createAccount(user) {
    return db('account')
        .insert(user);
}

function get() {
    return db('account')
}

function loginUser(email) {
    return db('account')
        .where({email: email})
        .first()
}